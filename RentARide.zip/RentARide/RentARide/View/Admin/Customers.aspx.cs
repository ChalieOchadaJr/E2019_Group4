﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RentARide.View.Admin
{
    public partial class Customers : System.Web.UI.Page
    {
        Models.Functions Conn;
        protected void Page_Load(object sender, EventArgs e)
        {
            Conn = new Models.Functions();
            ShowCustomers();


        }
        private void ShowCustomers()
        {
            string Query = "select * from CustomerTbl";
            CustomerList.DataSource = Conn.GetData(Query);
            CustomerList.DataBind();
        }
        public override void VerifyRenderingInServerForm(Control control)
        {
            try
            {
                if (CustNameTb.Value == "" || CustPhoneTb.Value == "" || PasswordTb.Value == "" || AddTb.Value == "")
                {
                    ErrorMsg.InnerText = "Missing Information";
                }
                else
                {
                    string CustName = CustNameTb.Value;
                    string CustAdd = AddTb.Value;
                    string CustPhone = CustPhoneTb.Value;
                    string CustPass = PasswordTb.Value;
                    string Query = " insert into CustomerTbl values('{0}','{1}','{2}','{3}')";
                    Query = string.Format(Query, CustName, CustAdd, CustPhone, CustPass);
                    Conn.SetData(Query);
                    ShowCustomers();
                    ErrorMsg.InnerText = "Customer Added";

                }
            }
            catch (Exception Ex)
            {

                //throw;
                ErrorMsg.InnerText = Ex.Message;
            }
        }
        }
    }
